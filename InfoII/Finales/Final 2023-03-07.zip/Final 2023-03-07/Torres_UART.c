#include    <stdio.h>

#define MY_BUFF    64
#define MY_OK       1
#define MY_ERR      0

  

__uint16_t buffer_tx[MY_BUFF];
__uint8_t tx_in,tx_out=0; //indices de transmición de entrada y salida.
__uint8_t paridad;

__uint8_t tick; // ticks para transmitir

__uint8_t MyTx(__uint8_t data)
{
       
    if(tx_in >= MY_BUFF)// si está lleno
        {
            tx_in=0;
            return MY_ERR;
        }
    
    buffer_tx[tx_in]= data; // guardo el 1 byte en el buffer de transmisión
    if(paridad = get_par(data))
        return MY_ERR;          //si hay error de paridad devuelvo error
    tx_in++;    

    return MY_OK;       
    
}

__uint8_t get_par(__uint8_t data)
{
    if((data & 0x01)^((data>>1) & 0x01)^((data>>2) &0x01)^((data>>3) &0x01)^((data>>4) &0x01)
                                                ^((data>>5) &0x01)^((data>>6) &0x01)^((data>>7) &0x01)) //xor de todos los bits
        return paridad = 1;
}

void get_trama(void)
{
    __uint32_t trama;
    __uint8_t i;
    
    if(tx_out != tx_in) //que no se pisen los índices
        {
            trama = buffer_tx[tx_out];

            set_pin(p0,1,0);   //bit de start en 0
            set_pin(p0,2,0);   //bit de start en 0
            for (i=0 , i<=7, i++)
            {
                set_pin(p0,(i+2),(get_pin((trama >> i))|0x01));
            }
            
            if(paridad)
                set_pin(p0,10,0);
            else
                set_pin(p0,10,1);
            set_pin(p0,12,1); //bit de stop
            set_pin(p0,12,1);

        }   
}

void MyTick(void)
{
    uint8_t iir, aux,i;
    i=0;

    if(tick++=8)
    {    
        do
        {
            iir = U1IIR;

            if ( iir & 0x02 ) //THRE- transmisión
            {
                if (tx_out<TX_TOPE)
                    U1THR = get_pin(p0,i++);
                else
                    tx_out = 0;  //Finalizo el envio.

            }
        }
        while( (! ( iir & 0x01 )&& i<13) );
    }
    
}

void Systick_Handler(void) // se ejecuta cada 1 tick
{
    tick=0;
    MyTick();
    if (tick==8)
        tick=0;
}

